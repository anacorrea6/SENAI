
from machine import Pin
from utime import sleep
from dht import DHT22

sensor_t = DHT22(Pin(15))

led_atencao = Pin(12, Pin.OUT)

while True:
    sensor_t.measure()
    temperatura = sensor_t.temperature()
    umidade = sensor_t.humidity()

    if temperatura > 30:
        print("ALERTA, TEMPERATURA MUITO ALTA!")
        led_atencao.on()
        sleep(1)
    else:
        print(f"a temperatura atual é de: {temperatura} °C")
        print(f"a umidade atual é de: {umidade:.2%}")
        led_atencao.off()

    sleep(2)





'''
from machine import Pin
from utime import sleep
from dht import DHT22

sensor_t = DHT22(Pin(15)) #Porta que está vindo o DHT

led_atencao = Pin(12, Pin.OUT) #Porta qe o LED está conectado

while True:
    sensor_t.measure()
    temperatura = sensor_t.temperature()
    umidade = sensor_t.humidity()

    if temperatura > 30:
        print("Alerta!!! Temperatura muito alta")
        led_atencao.on()
        sleep(1)
    else:
        print(f"A temperatura atual é de:{temperatura}°C ")
        print (f"A humidade atual é de: {humidade:.2% }")
        led_atencao.off()
    sleep(2)
'''
