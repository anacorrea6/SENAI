from machine import Pin
from utime import sleep_us

dir_ = Pin(16, Pin.OUT)
step_ = Pin(17, Pin.OUT)

while True:
    passos = int(input("Digite o número de passos: "))
    print("Escolha o sentido:")
    print("Horário: 1")
    print("Antihorário: 2")
    sentido = int(input("Digite 1 ou 2: "))

    if sentido == 1:
        dir_.value(1)
    else:
        dir_.value(0)

    for i in range(passos):
        step_.value(1)
        sleep_us(1000)  # Pulso alto por 1 ms
        step_.value(0)
        sleep_us(1000)  # Pulso baixo por 1 ms
