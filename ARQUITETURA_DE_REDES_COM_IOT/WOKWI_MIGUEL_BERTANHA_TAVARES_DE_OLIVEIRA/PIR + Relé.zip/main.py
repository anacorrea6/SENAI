from machine import Pin
from utime import sleep

#Relé vai ligar a lâmpada 
rele = Pin(16, Pin.OUT)
#Sensor que vai detectar a presença
sensor = Pin(15, Pin.IN)

while True: 
    #Aqui vamos guardar o valor do PIR
    detectou = sensor.value()

    #se detectar presença, liga a LÂMPADA (O RELE liga ela)
    if detectou == 1:
        rele.on()
        detectou = 1
        print("Foi identificado um ser vivo")
    else: 
        rele.off()
        detectou = 0
        print("Não foi detectado nenhum ser vivo")

    sleep(0.005)

