print("olá usuario, me de a temperatura em  Celsius e eu vou retonar a temperatrura em fahrenheit, ou vice-versa")

tempo = float(input("digite a temperatura:"))
tptemp = input("me de a temperatura emn Celsius ou Fanrenheit, C ou F")
def contc (tempo, tptemp):
    if tptemp == "c" and tptemp == "C":
        conct = (Tempo - 32) *5 /9
        print(" A temperatura em Celsius é de:", Contc)
    elif tptemp == "f" and tptemp == "F":
        conft = 9/5 *tempo + 32
        print(" A temeperatura em fanrenheit é de: " ,Contf)
    conct (tempo,tempereatura)
