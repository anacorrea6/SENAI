Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=========== RESTART: C:\Users\2anoA\Documents\senai\LOPAL\teste 2.py ===========
oi usuário, vou fazer a média para voce de 3 salários!
digite o primeiro salário:6000.6
digite o segundo salário:6000.6
digite o terceiro salário:6000.6
o resultado da media é:  6000.600000000001
>>> 
=============================================================== RESTART: C:\Users\2anoA\Documents\senai\LOPAL\teste 2.py ===============================================================
oi usuário, vou fazer a média para voce de 3 salários!
digite o primeiro salário:
=========== RESTART: C:\Users\2anoA\Documents\senai\LOPAL\teste 2.py ===========
oi usuário, vou fazer a média para voce de 3 salários!
digite o primeiro salário:
=========== RESTART: C:\Users\2anoA\Documents\senai\LOPAL\teste 2.py ===========
oi usuário, vou fazer a média para voce de 3 salários!
digite o primeiro salário:900.0
digite o segundo salário:8800.0
digite o terceiro salário:9900.9
o resultado da media é: 6533.63 
