#-*- coding: UTF-8 -*-
print("oi usuário, vou fazer a média para voce de 3 salários!")
salario1 = float(input("digite o primeiro salário:"))
salario2 = float(input("digite o segundo salário:"))
salario3 = float(input("digite o terceiro salário:"))
media_salarios = (salario1+salario2+salario3) /3
print("o resultado da media é: %.2f " %media_salarios)
